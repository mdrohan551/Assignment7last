export const MONGODB_URL= "mongodb+srv://roots:roots@cluster0.3pcbx.mongodb.net/assignments_modules_26"

//ACCESS TOKEN
export const JWT_SECRET_TOKEN= "123RohanAzim"
export const JWT_EXPIRATION_TIME_TOKEN = "5h"

export const Max_JSON_SIZE = "50mb"
export const URL_ENCODER = true

export const REQUEST_LIMIT_TIME = 15 * 60 * 1000
export const REQUEST_LIMIT_NUMBER = 9999999999

export const WEB_CACHE = false
export const PORT = 4000
